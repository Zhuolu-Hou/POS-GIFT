clc;clear;close all; warning('off')
addpath('.\PC');
addpath('.\Demo\des');
addpath('.\Demo');
file_image='.\Dataset\';
[filename,pathname]=uigetfile({'*.*','All Files(*.*)'},'Select reference image',file_image);
im1=imread(strcat(pathname,filename));
[filename,pathname]=uigetfile({'*.*','All Files(*.*)'},'Select the sensed image',file_image);
im2=imread(strcat(pathname,filename));
% parameter
pointnumber = 5000;scale = 4;
demo = 'rotation_max';% If the image is not rotated, we suggest setting demo to' ‘common‘'. 
%
[cleanedPoints1,cleanedPoints2,H] = POS_GIFT_demo(im1,im2,demo,scale,pointnumber);