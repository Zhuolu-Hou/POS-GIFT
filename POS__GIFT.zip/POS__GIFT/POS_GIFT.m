clc;clear;close all; warning('off')

addpath('.\PC');addpath('.\Demo\des');addpath('.\Demo');

% Read image pair
file_image='.\dataset\';
[filename,pathname]=uigetfile({'*.*','All Files(*.*)'},'Select reference image',file_image);
im1 = imread(strcat(pathname,filename));
[filename,pathname]=uigetfile({'*.*','All Files(*.*)'},'Select the sensed image',file_image);
im2 = imread(strcat(pathname,filename));

% Parameter
pointnumber = 5000;                      % The max number of feature points
scale = 4;                               % The number of layers of the image pyramid
s = 4;                                   % scale of Log-Gabor filters
o = 6;                                   % orientation of Log-Gabor filters
demo = 'common';                         % If there is rotation in the image, we suggest setting demo to 'rotation_max'.

% Multimodel image matching by POS-GIFT.
[cleanedPoints1,cleanedPoints2,H] = POS_GIFT_demo(im1,im2,demo,scale,s,o,pointnumber);

% show image matching result
figure('NumberTitle','on','Name',['POS-GIFT-matching-result: NCM:',num2str(size(cleanedPoints1,1))]); showMatchedFeatures(im1, im2, cleanedPoints1, cleanedPoints2, 'montage');